"""
Утилиты для бота
"""
from .logger import bot_logger

__all__ = ['bot_logger']
