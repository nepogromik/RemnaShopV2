import os
import logging
from datetime import datetime, timedelta, timezone
from typing import Optional, Tuple, Dict, Any

import aiohttp

logger = logging.getLogger(__name__)

# Функции для получения переменных окружения (ленивая загрузка)
def get_base_url() -> str:
    return os.getenv("REMNA_BASE_URL", "").rstrip("/")

def get_api_token() -> str:
    return os.getenv("REMNA_API_TOKEN", "")

def get_inbound_id() -> int:
    return int(os.getenv("REMNA_INBOUND_ID", "1"))

def get_default_days() -> int:
    return int(os.getenv("REMNA_DEFAULT_DAYS", "30"))

def get_data_limit_gb() -> int:
    return int(os.getenv("REMNA_DATA_LIMIT_GB", "500"))

def get_headers() -> Dict[str, str]:
    """Возвращает заголовки для API запросов"""
    token = get_api_token()
    if not token:
        return {}
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

def _unix_timestamp(days: int) -> int:
    """Returns Unix timestamp for now + days"""
    return int((datetime.now(timezone.utc) + timedelta(days=days)).timestamp())

async def _fetch_json(session: aiohttp.ClientSession, method: str, path: str, **kwargs) -> Optional[Dict[str, Any]]:
    """Universal API request handler for Remnawave v2.2.4"""
    base_url = get_base_url()
    headers = get_headers()
    
    url = f"{base_url}{path}"
    try:
        async with session.request(method, url, headers=headers, **kwargs) as resp:
            txt = await resp.text()
            if resp.status >= 400:
                logger.error(f"Remna API {method} {path} failed {resp.status}: {txt}")
                return None
            try:
                data = await resp.json()
                # v2.2.4 response format: {success: bool, data: {...}, message: str}
                if not data.get('success'):
                    logger.error(f"API error: {data.get('message', 'Unknown error')}")
                    return None
                return data
            except Exception as e:
                logger.error(f"Failed to parse JSON from {path}: {txt[:200]}, error: {e}")
                return None
    except Exception as e:
        logger.error(f"HTTP error {method} {path}: {e}")
        return None

# Cache for inbound info
_INBOUND_CACHE: Optional[Dict[str, Any]] = None

async def get_inbound(session: aiohttp.ClientSession, force_refresh: bool = False) -> Optional[Dict[str, Any]]:
    """Get inbound by INBOUND_ID from /api/v1/inbounds"""
    global _INBOUND_CACHE
    if _INBOUND_CACHE and not force_refresh:
        return _INBOUND_CACHE
    
    base_url = get_base_url()
    api_token = get_api_token()
    inbound_id = get_inbound_id()
    
    if not base_url or not api_token:
        logger.error("Remna config incomplete: BASE_URL or API_TOKEN missing")
        return None
    
    # GET /api/v1/inbounds
    result = await _fetch_json(session, 'GET', '/api/v1/inbounds')
    if not result or 'data' not in result:
        return None
    
    inbounds = result['data']
    if isinstance(inbounds, list):
        for inbound in inbounds:
            if inbound.get('id') == inbound_id:
                _INBOUND_CACHE = inbound
                return _INBOUND_CACHE
    
    logger.error(f"Inbound with ID {inbound_id} not found")
    return None

async def get_user_by_email(session: aiohttp.ClientSession, email: str) -> Optional[Dict[str, Any]]:
    """Get user by email from /api/v1/users"""
    # GET /api/v1/users with filter
    result = await _fetch_json(session, 'GET', f'/api/v1/users?email={email}')
    if result and 'data' in result:
        users = result['data']
        if isinstance(users, list) and users:
            return users[0]
    return None

async def get_user_by_telegram_id(session: aiohttp.ClientSession, telegram_id: str) -> Optional[Dict[str, Any]]:
    """Get user by telegram_id - search through all users"""
    result = await _fetch_json(session, 'GET', '/api/v1/users')
    if result and 'data' in result:
        users = result['data']
        if isinstance(users, list):
            for user in users:
                # Check if user has telegram_id in metadata or custom field
                if str(user.get('telegram_id')) == telegram_id or str(user.get('email', '')).startswith(f'tg{telegram_id}'):
                    return user
    return None

async def create_or_extend_user(session: aiohttp.ClientSession, email: str, days_to_add: int, telegram_id: str = None) -> Tuple[Optional[int], Optional[str], Optional[int]]:
    """
    Create new user or extend existing one
    Returns (user_id, config_url, expire_timestamp)
    """
    # Try to find existing user
    existing = await get_user_by_email(session, email)
    
    now_ts = int(datetime.now(timezone.utc).timestamp())
    
    if existing:
        # Extend existing user using POST /api/v1/users/{id}/extend
        user_id = existing.get('id')
        current_expire = existing.get('expire', now_ts)
        
        # Calculate new expiry
        base_ts = max(current_expire, now_ts)
        days_seconds = days_to_add * 24 * 3600
        new_expire = base_ts + days_seconds
        
        # Use extend endpoint
        extend_result = await _fetch_json(
            session, 
            'POST', 
            f'/api/v1/users/{user_id}/extend',
            json={"days": days_to_add}
        )
        
        if extend_result and 'data' in extend_result:
            user_data = extend_result['data']
            return user_data.get('id'), user_data.get('config'), user_data.get('expire')
        return None, None, None
    
    # Create new user
    new_expire = _unix_timestamp(days_to_add)
    data_limit_bytes = get_data_limit_gb() * 1024 * 1024 * 1024
    inbound_id = get_inbound_id()
    
    body = {
        "email": email,
        "expire": new_expire,
        "data_limit": data_limit_bytes,
        "inbound_id": inbound_id,
        "status": "active"
    }
    
    # Store telegram_id in email prefix for easy search
    if telegram_id:
        body["email"] = f"tg{telegram_id}-{email}"
    
    created = await _fetch_json(session, 'POST', '/api/v1/users', json=body)
    if created and 'data' in created:
        user_data = created['data']
        return user_data.get('id'), user_data.get('config'), user_data.get('expire')
    
    return None, None, None

async def provision_key(email: str, days: int | None = None, telegram_id: str = None) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """
    Main function to create/extend user and get config
    Returns (config_string, expire_iso, user_id_str)
    """
    days = days or get_default_days()
    async with aiohttp.ClientSession() as session:
        # Ensure inbound exists
        inbound = await get_inbound(session)
        if not inbound:
            logger.error("Failed to get inbound")
            return None, None, None
        
        user_id, config, expire_ts = await create_or_extend_user(session, email, days, telegram_id)
        if not user_id or not config:
            logger.error("Failed to create/extend user")
            return None, None, None
        
        # Convert timestamp to ISO format
        expire_dt = datetime.fromtimestamp(expire_ts, tz=timezone.utc)
        expire_iso = expire_dt.isoformat().replace('+00:00', 'Z')
        
        return config, expire_iso, str(user_id)

async def add_extra_traffic(email: str, extra_gb: int, telegram_id: str = None) -> bool:
    """Add extra traffic to user's data limit"""
    bytes_add = extra_gb * 1024 * 1024 * 1024
    async with aiohttp.ClientSession() as session:
        user = await get_user_by_email(session, email)
        if not user:
            return False
        
        user_id = user.get('id')
        current_limit = user.get('data_limit', 0)
        new_limit = current_limit + bytes_add
        
        # PATCH /api/v1/users/{id}
        updated = await _fetch_json(
            session, 
            'PATCH', 
            f'/api/v1/users/{user_id}',
            json={"data_limit": new_limit}
        )
        
        return bool(updated and 'data' in updated)
